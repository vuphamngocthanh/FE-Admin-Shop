import App from "../../App";

import LoginForm from "../common/LoginForm";

function Login() {

  return(
    <LoginForm />
  );
}

export default Login;
